import React from 'react';
import ReactDOM from 'react-dom';

import States from './components/states/States';

ReactDOM.render(
  <States />,
  document.getElementById('reactapp'),
);
